package com.gym.config;

import com.gym.model.*;
import com.gym.repository.*;
import com.gym.service.AttendanceService;
import com.gym.service.BillingService;
import com.gym.service.NotificationService;
import com.gym.service.QueryService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Inserts demo data the first time the app starts (only when the plan table is empty). */
@Component
public class DataInitializer implements CommandLineRunner {

    @Value("${gym.seed-demo-data:true}")
    private boolean seed;

    @Value("${gym.admin.username}")
    private String adminUsername;
    @Value("${gym.admin.password}")
    private String adminPassword;
    @Value("${gym.admin.email:admin@fitzone.com}")
    private String adminEmail;

    private final UserAccountRepository accounts;
    private final PasswordEncoder encoder;
    private final MembershipPlanRepository plans;
    private final TrainerRepository trainers;
    private final MemberRepository members;
    private final BillingService billing;
    private final AttendanceService attendance;
    private final NotificationService notifications;
    private final QueryService queries;
    private final AnnouncementRepository announcements;

    public DataInitializer(UserAccountRepository accounts, PasswordEncoder encoder, MembershipPlanRepository plans, TrainerRepository trainers, MemberRepository members,
                           BillingService billing, AttendanceService attendance, NotificationService notifications,
                           QueryService queries, AnnouncementRepository announcements) {
        this.notifications = notifications;
        this.queries = queries;
        this.announcements = announcements;
        this.accounts = accounts;
        this.encoder = encoder;
        this.plans = plans;
        this.trainers = trainers;
        this.members = members;
        this.billing = billing;
        this.attendance = attendance;
    }

    @Override
    public void run(String... args) {
        ensureAdmin();
        if (!seed || plans.count() > 0) return;

        MembershipPlan basic = plan("Basic Monthly", PlanType.BASIC, 1, "1000", "Gym floor access");
        MembershipPlan premium = plan("Premium Quarterly", PlanType.PREMIUM, 3, "2700", "Gym + cardio + group classes");
        MembershipPlan vip = plan("VIP Yearly", PlanType.VIP, 12, "9000", "All access + personal trainer + diet plan");

        Trainer t1 = trainer("Rahul Patil", "rahul@fitzone.com", "9890000001", "Strength Training", 5);
        Trainer t2 = trainer("Sneha Kulkarni", "sneha@fitzone.com", "9890000002", "Yoga & Cardio", 3);

        Member m1 = member("Amit Deshmukh", "amit@example.com", "9922000001", "Male", premium, t1, null);
        account(m1, "member123");
        Member m2 = member("Priya Joshi", "priya@example.com", "9922000002", "Female", basic, t2, LocalDate.now().plusDays(3));
        member("Rohan Shinde", "rohan@example.com", "9922000003", "Male", vip, t1, LocalDate.now().minusDays(5));

        Invoice inv = billing.generateInvoice(m1.getId(), null);
        billing.addPayment(inv.getId(), new BigDecimal("1500"), PaymentMode.UPI);
        attendance.mark(m1.getId());
        attendance.mark(m2.getId());

        // a new registration waiting for the owner (no trainer, no invoice yet)
        Member m4 = member("Neha Kale", "neha@example.com", "9922000004", "Female", basic, null, null);
        m4.setJoinDate(LocalDate.now());
        members.save(m4);
        account(m4, "member123");
        notifications.notifyOwner("New member registered: " + m4.getName(),
                m4.getName() + " (" + m4.getPhone() + ") selected " + basic.getName()
                        + ". Assign a trainer and generate the first invoice.", "/members/" + m4.getId());

        // a sample query from a member + a notice from the owner
        queries.create(m1.getId(), "Change my timing", QueryCategory.GENERAL,
                "Can I shift my slot from morning to evening from next week?");
        Announcement a = new Announcement();
        a.setTitle("Gym closed on Sunday");
        a.setMessage("The gym will remain closed this Sunday for maintenance. Regular timings from Monday.");
        announcements.save(a);
    }

    private void ensureAdmin() {
        if (accounts.existsByUsernameIgnoreCase(adminUsername)) return;
        UserAccount a = new UserAccount();
        a.setUsername(adminUsername);
        a.setEmail(adminEmail);
        a.setFullName("Administrator");
        a.setPassword(encoder.encode(adminPassword));
        a.setRole("ADMIN");
        accounts.save(a);
    }

    private void account(Member m, String rawPassword) {
        UserAccount a = new UserAccount();
        a.setUsername(m.getEmail());
        a.setEmail(m.getEmail());
        a.setFullName(m.getName());
        a.setPassword(encoder.encode(rawPassword));
        a.setRole("MEMBER");
        a.setMember(m);
        accounts.save(a);
    }

    private MembershipPlan plan(String name, PlanType type, int months, String price, String desc) {
        MembershipPlan p = new MembershipPlan();
        p.setName(name);
        p.setType(type);
        p.setDurationMonths(months);
        p.setPrice(new BigDecimal(price));
        p.setDescription(desc);
        return plans.save(p);
    }

    private Trainer trainer(String name, String email, String phone, String spec, int years) {
        Trainer t = new Trainer();
        t.setName(name);
        t.setEmail(email);
        t.setPhone(phone);
        t.setSpecialization(spec);
        t.setExperienceYears(years);
        return trainers.save(t);
    }

    private Member member(String name, String email, String phone, String gender,
                          MembershipPlan plan, Trainer trainer, LocalDate expiry) {
        Member m = new Member();
        m.setName(name);
        m.setEmail(email);
        m.setPhone(phone);
        m.setGender(gender);
        m.setPlan(plan);
        m.setTrainer(trainer);
        m.setJoinDate(LocalDate.now().minusDays(10));
        m.setExpiryDate(expiry);
        m.setActive(true);
        return members.save(m);
    }
}
