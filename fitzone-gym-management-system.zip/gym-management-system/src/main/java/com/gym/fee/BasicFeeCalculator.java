package com.gym.fee;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Basic plan: 0% discount. */
public class BasicFeeCalculator implements FeeCalculator {
    @Override
    public BigDecimal calculateDiscount(BigDecimal baseAmount) {
        return baseAmount.multiply(new BigDecimal("0")).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
    }
}
