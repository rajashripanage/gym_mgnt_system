package com.gym.fee;

import java.math.BigDecimal;

/** Every membership type calculates its own discount (Polymorphism). */
public interface FeeCalculator {
    BigDecimal calculateDiscount(BigDecimal baseAmount);
}
