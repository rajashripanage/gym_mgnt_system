package com.gym.fee;

import com.gym.model.PlanType;

public class FeeCalculatorFactory {
    private FeeCalculatorFactory() {}

    public static FeeCalculator forType(PlanType type) {
        return switch (type) {
            case BASIC -> new BasicFeeCalculator();
            case PREMIUM -> new PremiumFeeCalculator();
            case VIP -> new VipFeeCalculator();
        };
    }
}
