package com.gym.fee;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Vip plan: 10% discount. */
public class VipFeeCalculator implements FeeCalculator {
    @Override
    public BigDecimal calculateDiscount(BigDecimal baseAmount) {
        return baseAmount.multiply(new BigDecimal("10")).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
    }
}
