package com.gym.fee;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Premium plan: 5% discount. */
public class PremiumFeeCalculator implements FeeCalculator {
    @Override
    public BigDecimal calculateDiscount(BigDecimal baseAmount) {
        return baseAmount.multiply(new BigDecimal("5")).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
    }
}
