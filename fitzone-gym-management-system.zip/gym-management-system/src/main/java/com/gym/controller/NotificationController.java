package com.gym.controller;

import com.gym.model.Notification;
import com.gym.service.NotificationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/** Owner's notification centre (new registrations, member queries, ...). */
@Controller
@RequestMapping("/notifications")
public class NotificationController {

    private final NotificationService service;

    public NotificationController(NotificationService service) {
        this.service = service;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("notifications", service.ownerList());
        return "notifications";
    }

    @PostMapping("/read-all")
    public String readAll() {
        service.markAllOwnerRead();
        return "redirect:/notifications";
    }

    /** Marks the notification as read and jumps to the related page. */
    @GetMapping("/{id}/open")
    public String open(@PathVariable Long id) {
        Notification n = service.open(id);
        return "redirect:" + (n.getLink() == null || n.getLink().isBlank() ? "/notifications" : n.getLink());
    }
}
