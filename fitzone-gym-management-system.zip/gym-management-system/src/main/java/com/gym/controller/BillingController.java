package com.gym.controller;

import com.gym.model.PaymentMode;
import com.gym.repository.MemberRepository;
import com.gym.repository.MembershipPlanRepository;
import com.gym.model.Invoice;
import com.gym.service.BillingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.gym.model.Payment;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

@Controller
public class BillingController {

    private final BillingService billing;
    private final MemberRepository members;
    private final MembershipPlanRepository plans;

    public BillingController(BillingService billing, MemberRepository members, MembershipPlanRepository plans) {
        this.billing = billing;
        this.members = members;
        this.plans = plans;
    }

    // ---------------- invoices ----------------
    @GetMapping("/invoices")
    public String invoices(Model model) {
        model.addAttribute("invoices", billing.allInvoices());
        model.addAttribute("members", members.findAll());
        model.addAttribute("plans", plans.findAll());
        return "invoices";
    }

    @PostMapping("/invoices/generate")
    public String generate(@RequestParam Long memberId, @RequestParam(required = false) Long planId,
                           @RequestParam(required = false) BigDecimal extraDiscount,
                           @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dueDate,
                           @RequestParam(required = false) String notes,
                           RedirectAttributes ra) {
        try {
            Invoice inv = billing.generateInvoice(memberId, planId, extraDiscount, dueDate, notes);
            ra.addFlashAttribute("success", "Invoice " + inv.getInvoiceNumber() + " generated");
            return "redirect:/invoices/" + inv.getId();
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/invoices";
        }
    }

    @GetMapping("/invoices/{id}")
    public String invoice(@PathVariable Long id, Model model) {
        model.addAttribute("invoice", billing.getInvoice(id));
        model.addAttribute("payments", billing.paymentsOf(id));
        model.addAttribute("modes", PaymentMode.values());
        model.addAttribute("portal", false);
        return "invoice-view";
    }

    // ---------------- payments ----------------
    @GetMapping("/payments")
    public String payments(Model model) {
        model.addAttribute("payments", billing.allPayments());
        model.addAttribute("unpaid", billing.unpaidInvoices());
        model.addAttribute("modes", PaymentMode.values());
        return "payments";
    }

    @PostMapping("/payments/add")
    public String addPayment(@RequestParam Long invoiceId, @RequestParam BigDecimal amount,
                             @RequestParam PaymentMode mode,
                             @RequestParam(required = false) String reference,
                             @RequestParam(defaultValue = "payments") String back, RedirectAttributes ra) {
        Long memberId = null;
        try {
            Payment p = billing.addPayment(invoiceId, amount, mode, reference);
            memberId = p.getInvoice().getMember().getId();
            ra.addFlashAttribute("success", "Payment recorded - receipt " + p.getReceiptNumber());
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            memberId = billing.getInvoice(invoiceId).getMember().getId();
        }
        if ("invoice".equals(back)) return "redirect:/invoices/" + invoiceId;
        if ("member".equals(back)) return "redirect:/members/" + memberId;
        return "redirect:/payments";
    }

    /** Printable payment receipt. */
    @GetMapping("/payments/{id}/receipt")
    public String receipt(@PathVariable Long id, Model model) {
        model.addAttribute("payment", billing.getPayment(id));
        model.addAttribute("portal", false);
        return "receipt";
    }
}
