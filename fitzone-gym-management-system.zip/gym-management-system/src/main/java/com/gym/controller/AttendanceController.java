package com.gym.controller;

import com.gym.exception.DuplicateException;
import com.gym.repository.MemberRepository;
import com.gym.service.AttendanceService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
@RequestMapping("/attendance")
public class AttendanceController {

    private final AttendanceService service;
    private final MemberRepository members;

    public AttendanceController(AttendanceService service, MemberRepository members) {
        this.service = service;
        this.members = members;
    }

    @GetMapping
    public String view(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                       Model model) {
        LocalDate d = (date == null) ? LocalDate.now() : date;
        model.addAttribute("date", d);
        model.addAttribute("records", service.byDate(d));
        model.addAttribute("members", members.findByActiveTrueOrderByNameAsc());
        return "attendance";
    }

    @PostMapping("/mark")
    public String mark(@RequestParam Long memberId, @RequestParam(defaultValue = "attendance") String back,
                       RedirectAttributes ra) {
        try {
            service.mark(memberId);
            ra.addFlashAttribute("success", "Attendance marked");
        } catch (DuplicateException | IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "member".equals(back) ? "redirect:/members/" + memberId : "redirect:/attendance";
    }

    /** Records the time the member leaves the gym. */
    @PostMapping("/{id}/checkout")
    public String checkOut(@PathVariable Long id, @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                           RedirectAttributes ra) {
        try {
            service.checkOut(id);
            ra.addFlashAttribute("success", "Check-out recorded");
        } catch (DuplicateException | IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/attendance" + (date == null ? "" : "?date=" + date);
    }
}
