package com.gym.controller;

import com.gym.model.UserAccount;
import com.gym.repository.UserAccountRepository;
import com.gym.service.NotificationService;
import com.gym.service.QueryService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

/** Adds the unread-notification counters used by the navigation bars (bell icon, queries badge). */
@ControllerAdvice
public class GlobalModelAdvice {

    private final NotificationService notifications;
    private final QueryService queries;
    private final UserAccountRepository accounts;

    public GlobalModelAdvice(NotificationService notifications, QueryService queries, UserAccountRepository accounts) {
        this.notifications = notifications;
        this.queries = queries;
        this.accounts = accounts;
    }

    @ModelAttribute("ownerUnread")
    public Long ownerUnread(Authentication auth, HttpServletRequest request) {
        if (!isPage(auth, request) || !hasRole(auth, "ROLE_ADMIN")) return 0L;
        return notifications.ownerUnread();
    }

    @ModelAttribute("openQueryCount")
    public Long openQueryCount(Authentication auth, HttpServletRequest request) {
        if (!isPage(auth, request) || !hasRole(auth, "ROLE_ADMIN")) return 0L;
        return queries.openCount();
    }

    @ModelAttribute("memberUnread")
    public Long memberUnread(Authentication auth, HttpServletRequest request) {
        if (!isPage(auth, request) || !hasRole(auth, "ROLE_MEMBER")) return 0L;
        return accounts.findByUsernameIgnoreCaseOrEmailIgnoreCase(auth.getName(), auth.getName())
                .map(UserAccount::getMember)
                .map(m -> notifications.memberUnread(m.getId()))
                .orElse(0L);
    }

    private boolean isPage(Authentication auth, HttpServletRequest request) {
        return auth != null && auth.isAuthenticated() && !request.getRequestURI().startsWith("/api");
    }

    private boolean hasRole(Authentication auth, String role) {
        return auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals(role));
    }
}
