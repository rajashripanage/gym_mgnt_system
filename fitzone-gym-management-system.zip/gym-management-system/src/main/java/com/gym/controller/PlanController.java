package com.gym.controller;

import com.gym.model.MembershipPlan;
import com.gym.model.PlanType;
import com.gym.repository.MembershipPlanRepository;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/plans")
public class PlanController {

    private final MembershipPlanRepository repo;

    public PlanController(MembershipPlanRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("plans", repo.findAll());
        model.addAttribute("plan", new MembershipPlan());
        model.addAttribute("types", PlanType.values());
        return "plans";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("plan") MembershipPlan plan, BindingResult result, RedirectAttributes ra) {
        if (result.hasErrors()) {
            ra.addFlashAttribute("error", result.getAllErrors().get(0).getDefaultMessage());
            return "redirect:/plans";
        }
        try {
            repo.save(plan);
            ra.addFlashAttribute("success", "Plan saved");
        } catch (DataIntegrityViolationException e) {
            ra.addFlashAttribute("error", "A plan with this name already exists");
        }
        return "redirect:/plans";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes ra) {
        try {
            repo.deleteById(id);
            ra.addFlashAttribute("success", "Plan deleted");
        } catch (DataIntegrityViolationException e) {
            ra.addFlashAttribute("error", "Cannot delete: this plan is used by members/invoices");
        }
        return "redirect:/plans";
    }
}
