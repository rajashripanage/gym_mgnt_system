package com.gym.controller;

import com.gym.exception.DuplicateException;
import com.gym.model.Member;
import com.gym.repository.MembershipPlanRepository;
import com.gym.repository.TrainerRepository;
import com.gym.model.Invoice;
import com.gym.model.PaymentMode;
import com.gym.service.AttendanceService;
import com.gym.service.BillingService;
import com.gym.service.MemberService;
import com.gym.service.QueryService;
import org.springframework.format.annotation.DateTimeFormat;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDate;

@Controller
@RequestMapping("/members")
public class MemberController {

    private final MemberService service;
    private final MembershipPlanRepository plans;
    private final TrainerRepository trainers;

    private final BillingService billing;
    private final AttendanceService attendance;
    private final QueryService queries;

    public MemberController(MemberService service, MembershipPlanRepository plans, TrainerRepository trainers,
                            BillingService billing, AttendanceService attendance, QueryService queries) {
        this.service = service;
        this.plans = plans;
        this.trainers = trainers;
        this.billing = billing;
        this.attendance = attendance;
        this.queries = queries;
    }

    @GetMapping
    public String list(@RequestParam(required = false) String q, Model model) {
        model.addAttribute("members", service.search(q));
        model.addAttribute("q", q);
        return "members";
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        Member m = new Member();
        m.setJoinDate(LocalDate.now());
        return form(m, model);
    }

    /** Full profile of a member for the owner: everything about the member in one place. */
    @GetMapping("/{id}")
    public String profile(@PathVariable Long id, Model model) {
        Member m = service.get(id);
        model.addAttribute("member", m);
        model.addAttribute("plans", plans.findAll());
        model.addAttribute("trainers", trainers.findAll());
        model.addAttribute("modes", PaymentMode.values());
        model.addAttribute("invoices", billing.invoicesOfMember(id));
        model.addAttribute("payments", billing.paymentsOfMember(id));
        model.addAttribute("due", billing.dueOfMember(id));
        model.addAttribute("attendance", attendance.recentOf(id));
        model.addAttribute("visitsThisMonth", attendance.visitsThisMonth(id));
        model.addAttribute("totalVisits", attendance.totalVisits(id));
        model.addAttribute("queries", queries.ofMember(id));
        return "member-profile";
    }

    @PostMapping("/{id}/assign")
    public String assign(@PathVariable Long id, @RequestParam(required = false) Long trainerId,
                         @RequestParam(required = false) Long planId, RedirectAttributes ra) {
        try {
            if (planId != null) service.assignPlan(id, planId);
            service.assignTrainer(id, trainerId);
            ra.addFlashAttribute("success", "Plan / trainer updated and the member is notified");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/members/" + id;
    }

    @PostMapping("/{id}/toggle-active")
    public String toggleActive(@PathVariable Long id, RedirectAttributes ra) {
        boolean activate = !service.get(id).isActive();
        service.setActive(id, activate);
        ra.addFlashAttribute("success", activate ? "Member activated" : "Member deactivated");
        return "redirect:/members/" + id;
    }

    @PostMapping("/{id}/notes")
    public String notes(@PathVariable Long id, @RequestParam(required = false) String notes, RedirectAttributes ra) {
        service.saveOwnerNotes(id, notes);
        ra.addFlashAttribute("success", "Notes saved");
        return "redirect:/members/" + id;
    }

    /** Generate invoice (first invoice = starts the membership, later = renewal) from the member profile. */
    @PostMapping("/{id}/invoice")
    public String invoice(@PathVariable Long id, @RequestParam(required = false) Long planId,
                          @RequestParam(required = false) BigDecimal extraDiscount,
                          @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dueDate,
                          @RequestParam(required = false) String notes, RedirectAttributes ra) {
        try {
            Invoice inv = billing.generateInvoice(id, planId, extraDiscount, dueDate, notes);
            ra.addFlashAttribute("success", "Invoice " + inv.getInvoiceNumber() + " generated - membership valid till "
                    + inv.getMember().getExpiryDate());
            return "redirect:/invoices/" + inv.getId();
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/members/" + id;
        }
    }

    @GetMapping("/{id}/edit")
    public String edit(@PathVariable Long id, Model model) {
        return form(service.get(id), model);
    }

    private String form(Member member, Model model) {
        model.addAttribute("member", member);
        model.addAttribute("plans", plans.findAll());
        model.addAttribute("trainers", trainers.findAll());
        return "member-form";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("member") Member member, BindingResult result,
                       @RequestParam(required = false) Long planId,
                       @RequestParam(required = false) Long trainerId,
                       Model model, RedirectAttributes ra) {
        if (result.hasErrors()) {
            return form(member, model);
        }
        try {
            service.save(member, planId, trainerId);
            ra.addFlashAttribute("success", "Member saved successfully");
            return "redirect:/members";
        } catch (DuplicateException e) {
            model.addAttribute("error", e.getMessage());
        } catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Email or phone number already exists");
        }
        return form(member, model);
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes ra) {
        try {
            service.delete(id);
            ra.addFlashAttribute("success", "Member deleted");
        } catch (DataIntegrityViolationException e) {
            ra.addFlashAttribute("error",
                "Cannot delete: this member has attendance/invoice records. Mark the member as inactive instead.");
        }
        return "redirect:/members";
    }
}
