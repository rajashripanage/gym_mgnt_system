package com.gym.controller;

import com.gym.model.QueryStatus;
import com.gym.model.SupportQuery;
import com.gym.service.QueryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

/** Owner side of member queries. */
@Controller
@RequestMapping("/queries")
public class QueryController {

    private final QueryService service;

    public QueryController(QueryService service) {
        this.service = service;
    }

    @GetMapping
    public String list(@RequestParam(required = false) QueryStatus status, Model model) {
        List<SupportQuery> all = service.all();
        if (status != null) {
            all = all.stream().filter(q -> q.getStatus() == status).toList();
        }
        model.addAttribute("queries", all);
        model.addAttribute("status", status);
        return "queries";
    }

    @GetMapping("/{id}")
    public String view(@PathVariable Long id, Model model) {
        model.addAttribute("query", service.get(id));
        return "query-view";
    }

    @PostMapping("/{id}/reply")
    public String reply(@PathVariable Long id, @RequestParam String text,
                        @RequestParam(defaultValue = "false") boolean close, RedirectAttributes ra) {
        try {
            service.ownerReply(id, text, close);
            ra.addFlashAttribute("success", close ? "Reply sent and query closed" : "Reply sent to the member");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/queries/" + id;
    }

    @PostMapping("/{id}/status")
    public String status(@PathVariable Long id, @RequestParam QueryStatus status, RedirectAttributes ra) {
        service.setStatus(id, status);
        ra.addFlashAttribute("success", "Query marked as " + status);
        return "redirect:/queries/" + id;
    }
}
