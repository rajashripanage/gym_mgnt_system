package com.gym.controller;

import com.gym.dto.RegisterForm;
import com.gym.exception.DuplicateException;
import com.gym.repository.MembershipPlanRepository;
import com.gym.service.PasswordResetService;
import com.gym.service.RegistrationService;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.Optional;

/** Login, registration, forgot password and reset password pages. */
@Controller
public class AuthController {

    private final RegistrationService registration;
    private final PasswordResetService passwordReset;
    private final MembershipPlanRepository plans;

    public AuthController(RegistrationService registration, PasswordResetService passwordReset,
                          MembershipPlanRepository plans) {
        this.registration = registration;
        this.passwordReset = passwordReset;
        this.plans = plans;
    }

    // ---------------- login ----------------
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    // ---------------- register ----------------
    @GetMapping("/register")
    public String registerForm(@RequestParam(required = false) Long plan, Model model) {
        RegisterForm form = new RegisterForm();
        form.setPlanId(plan);
        model.addAttribute("form", form);
        model.addAttribute("plans", plans.findAll());
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("form") RegisterForm form, BindingResult result,
                           Model model, RedirectAttributes ra) {
        model.addAttribute("plans", plans.findAll());
        if (result.hasErrors()) {
            return "register";
        }
        try {
            registration.register(form);
            ra.addFlashAttribute("success",
                "Registration successful! Login with your email and password. "
                + "Visit the gym desk to activate your membership.");
            return "redirect:/login";
        } catch (DuplicateException | IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
        } catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Email or phone is already registered");
        }
        return "register";
    }

    // ---------------- forgot password ----------------
    @GetMapping("/forgot-password")
    public String forgotForm() {
        return "forgot-password";
    }

    @PostMapping("/forgot-password")
    public String forgot(@RequestParam String email, Model model) {
        String baseUrl = ServletUriComponentsBuilder.fromCurrentContextPath().build().toUriString();
        Optional<String> link = passwordReset.requestReset(email, baseUrl);
        if (passwordReset.isMailEnabled()) {
            model.addAttribute("success", "If this email is registered, a reset link has been sent to it.");
        } else if (link.isPresent()) {
            // demo mode (no SMTP configured): show the link on screen
            model.addAttribute("success", "Reset link generated (demo mode - email is not configured). It is valid for 30 minutes.");
            model.addAttribute("devLink", link.get());
        } else {
            model.addAttribute("error", "No account found with this email");
        }
        return "forgot-password";
    }

    // ---------------- reset password ----------------
    @GetMapping("/reset-password")
    public String resetForm(@RequestParam(required = false) String token, Model model) {
        model.addAttribute("token", token);
        model.addAttribute("valid", passwordReset.isTokenValid(token));
        return "reset-password";
    }

    @PostMapping("/reset-password")
    public String reset(@RequestParam String token, @RequestParam String password,
                        @RequestParam String confirmPassword, Model model, RedirectAttributes ra) {
        model.addAttribute("token", token);
        model.addAttribute("valid", passwordReset.isTokenValid(token));
        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match");
            return "reset-password";
        }
        try {
            passwordReset.resetPassword(token, password);
            ra.addFlashAttribute("success", "Password changed successfully. Please login with your new password.");
            return "redirect:/login";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "reset-password";
        }
    }
}
