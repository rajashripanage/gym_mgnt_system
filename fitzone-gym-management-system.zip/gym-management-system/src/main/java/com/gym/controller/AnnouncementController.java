package com.gym.controller;

import com.gym.model.Announcement;
import com.gym.model.Member;
import com.gym.repository.AnnouncementRepository;
import com.gym.repository.MemberRepository;
import com.gym.service.NotificationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Owner posts notices (holiday, timing change, offers) that every member sees on the portal. */
@Controller
@RequestMapping("/announcements")
public class AnnouncementController {

    private final AnnouncementRepository repo;
    private final MemberRepository members;
    private final NotificationService notifications;

    public AnnouncementController(AnnouncementRepository repo, MemberRepository members, NotificationService notifications) {
        this.repo = repo;
        this.members = members;
        this.notifications = notifications;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("announcements", repo.findAllByOrderByIdDesc());
        return "announcements";
    }

    @PostMapping("/save")
    public String save(@RequestParam String title, @RequestParam String message, RedirectAttributes ra) {
        if (title.isBlank() || message.isBlank()) {
            ra.addFlashAttribute("error", "Title and message are required");
            return "redirect:/announcements";
        }
        Announcement a = new Announcement();
        a.setTitle(title.trim());
        a.setMessage(message.trim());
        repo.save(a);
        for (Member m : members.findByActiveTrueOrderByNameAsc()) {
            notifications.notifyMember(m, "Notice: " + a.getTitle(), a.getMessage(), "/portal");
        }
        ra.addFlashAttribute("success", "Announcement posted - all active members are notified");
        return "redirect:/announcements";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes ra) {
        repo.deleteById(id);
        ra.addFlashAttribute("success", "Announcement deleted");
        return "redirect:/announcements";
    }
}
