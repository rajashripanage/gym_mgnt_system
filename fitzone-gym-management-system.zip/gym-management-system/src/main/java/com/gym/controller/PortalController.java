package com.gym.controller;

import com.gym.exception.DuplicateException;
import com.gym.model.Member;
import com.gym.model.QueryCategory;
import com.gym.model.SupportQuery;
import com.gym.model.UserAccount;
import com.gym.repository.AnnouncementRepository;
import com.gym.repository.UserAccountRepository;
import com.gym.service.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Member portal: a logged-in member sees only his own data.
 * Everything else (trainer, plan, invoices, payments, attendance) is handled by the owner;
 * if the member has a doubt he raises a query from here and the owner replies.
 */
@Controller
@RequestMapping("/portal")
public class PortalController {

    private final UserAccountRepository accounts;
    private final AttendanceService attendance;
    private final BillingService billing;
    private final QueryService queries;
    private final NotificationService notifications;
    private final MemberService memberService;
    private final AnnouncementRepository announcements;

    public PortalController(UserAccountRepository accounts, AttendanceService attendance, BillingService billing,
                            QueryService queries, NotificationService notifications, MemberService memberService,
                            AnnouncementRepository announcements) {
        this.accounts = accounts;
        this.attendance = attendance;
        this.billing = billing;
        this.queries = queries;
        this.notifications = notifications;
        this.memberService = memberService;
        this.announcements = announcements;
    }

    /** The member of the logged-in account (null if the account has no member profile). */
    private Member currentMember(Principal principal) {
        UserAccount account = accounts
                .findByUsernameIgnoreCaseOrEmailIgnoreCase(principal.getName(), principal.getName())
                .orElseThrow(() -> new IllegalStateException("Account not found"));
        return account.getMember();
    }

    // ---------------- home ----------------
    @GetMapping
    public String portal(Principal principal, Model model) {
        Member member = currentMember(principal);
        if (member == null) {
            return "redirect:/";
        }
        Long daysLeft = (member.getExpiryDate() == null) ? null
                : ChronoUnit.DAYS.between(LocalDate.now(), member.getExpiryDate());

        model.addAttribute("member", member);
        model.addAttribute("daysLeft", daysLeft);
        model.addAttribute("attendance", attendance.recentOf(member.getId()));
        model.addAttribute("visitsThisMonth", attendance.visitsThisMonth(member.getId()));
        model.addAttribute("invoices", billing.invoicesOfMember(member.getId()));
        model.addAttribute("payments", billing.paymentsOfMember(member.getId()));
        model.addAttribute("due", billing.dueOfMember(member.getId()));
        model.addAttribute("openQueries", queries.ofMember(member.getId()).stream()
                .filter(q -> q.getStatus() != com.gym.model.QueryStatus.CLOSED).count());
        model.addAttribute("announcements", announcements.findTop5ByOrderByIdDesc());
        model.addAttribute("recentNotifications", notifications.memberList(member.getId()).stream().limit(4).toList());
        return "portal";
    }

    // ---------------- notifications ----------------
    @GetMapping("/notifications")
    public String notificationList(Principal principal, Model model) {
        Member member = currentMember(principal);
        model.addAttribute("member", member);
        model.addAttribute("notifications", notifications.memberList(member.getId()));
        return "portal-notifications";
    }

    @PostMapping("/notifications/read-all")
    public String readAll(Principal principal) {
        notifications.markAllMemberRead(currentMember(principal).getId());
        return "redirect:/portal/notifications";
    }

    @GetMapping("/notifications/{id}/open")
    public String openNotification(@PathVariable Long id, Principal principal) {
        Member member = currentMember(principal);
        // only the member's own notification can be opened
        var n = notifications.memberList(member.getId()).stream().filter(x -> x.getId().equals(id)).findFirst();
        if (n.isEmpty()) return "redirect:/portal/notifications";
        notifications.open(id);
        String link = n.get().getLink();
        return "redirect:" + (link == null || link.isBlank() ? "/portal/notifications" : link);
    }

    // ---------------- profile ----------------
    @GetMapping("/profile")
    public String profile(Principal principal, Model model) {
        model.addAttribute("member", currentMember(principal));
        return "portal-profile";
    }

    @PostMapping("/profile")
    public String saveProfile(Principal principal, @RequestParam String name, @RequestParam String phone,
                              @RequestParam(required = false) String gender,
                              @RequestParam(required = false) String address,
                              @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateOfBirth,
                              @RequestParam(required = false) String emergencyContact,
                              @RequestParam(required = false) String fitnessGoal, RedirectAttributes ra) {
        Member member = currentMember(principal);
        try {
            memberService.updateOwnProfile(member.getId(), name, phone, address, dateOfBirth,
                    emergencyContact, fitnessGoal, gender);
            ra.addFlashAttribute("success", "Profile updated");
        } catch (DuplicateException | IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/portal/profile";
    }

    @PostMapping("/password")
    public String changePassword(Principal principal, @RequestParam String currentPassword,
                                 @RequestParam String newPassword, @RequestParam String confirmPassword,
                                 RedirectAttributes ra) {
        try {
            memberService.changePassword(currentMember(principal).getId(), currentPassword, newPassword, confirmPassword);
            ra.addFlashAttribute("success", "Password changed");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/portal/profile";
    }

    // ---------------- invoices & receipts (read only) ----------------
    @GetMapping("/invoices/{id}")
    public String invoice(@PathVariable Long id, Principal principal, Model model, RedirectAttributes ra) {
        Member member = currentMember(principal);
        try {
            model.addAttribute("invoice", billing.getInvoiceForMember(id, member.getId()));
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/portal";
        }
        model.addAttribute("payments", billing.paymentsOf(id));
        model.addAttribute("portal", true);
        return "invoice-view";
    }

    @GetMapping("/receipts/{id}")
    public String receipt(@PathVariable Long id, Principal principal, Model model, RedirectAttributes ra) {
        Member member = currentMember(principal);
        try {
            model.addAttribute("payment", billing.getPaymentForMember(id, member.getId()));
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/portal";
        }
        model.addAttribute("portal", true);
        return "receipt";
    }

    // ---------------- queries (member -> owner) ----------------
    @GetMapping("/queries")
    public String queryList(Principal principal, Model model) {
        Member member = currentMember(principal);
        model.addAttribute("member", member);
        model.addAttribute("queries", queries.ofMember(member.getId()));
        model.addAttribute("categories", QueryCategory.values());
        return "portal-queries";
    }

    @PostMapping("/queries")
    public String newQuery(Principal principal, @RequestParam String subject,
                           @RequestParam(required = false) QueryCategory category,
                           @RequestParam String text, RedirectAttributes ra) {
        try {
            SupportQuery q = queries.create(currentMember(principal).getId(), subject, category, text);
            ra.addFlashAttribute("success", "Your query has been sent to the gym owner");
            return "redirect:/portal/queries/" + q.getId();
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/portal/queries";
        }
    }

    @GetMapping("/queries/{id}")
    public String queryView(@PathVariable Long id, Principal principal, Model model, RedirectAttributes ra) {
        Member member = currentMember(principal);
        try {
            model.addAttribute("query", queries.getForMember(id, member.getId()));
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/portal/queries";
        }
        model.addAttribute("member", member);
        return "portal-query";
    }

    @PostMapping("/queries/{id}/reply")
    public String queryReply(@PathVariable Long id, @RequestParam String text, Principal principal, RedirectAttributes ra) {
        try {
            queries.memberReply(id, currentMember(principal).getId(), text);
            ra.addFlashAttribute("success", "Message sent");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/portal/queries/" + id;
    }
}
