package com.gym.controller;

import com.gym.model.Member;
import com.gym.repository.MemberRepository;
import com.gym.model.SupportQuery;
import com.gym.model.QueryStatus;
import com.gym.repository.TrainerRepository;
import com.gym.service.DashboardService;
import com.gym.service.NotificationService;
import com.gym.service.QueryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Controller
public class DashboardController {

    private final DashboardService dashboard;
    private final MemberRepository members;
    private final NotificationService notifications;
    private final QueryService queries;
    private final TrainerRepository trainers;

    public DashboardController(DashboardService dashboard, MemberRepository members,
                               NotificationService notifications, QueryService queries, TrainerRepository trainers) {
        this.dashboard = dashboard;
        this.members = members;
        this.notifications = notifications;
        this.queries = queries;
        this.trainers = trainers;
    }

    @GetMapping("/dashboard")
    public String home(Model model) {
        LocalDate today = LocalDate.now();
        // Collections: ArrayList of members whose membership ends within 7 days, sorted by expiry date
        List<Member> expiringSoon = new ArrayList<>(members.findByExpiryDateBetween(today, today.plusDays(7)));
        expiringSoon.sort(Comparator.comparing(Member::getExpiryDate));

        List<SupportQuery> openQueries = queries.all().stream()
                .filter(q -> q.getStatus() == QueryStatus.OPEN).limit(5).toList();
        model.addAttribute("recentNotifications", notifications.ownerList().stream().limit(6).toList());
        model.addAttribute("openQueries", openQueries);
        model.addAttribute("trainers", trainers.findAll());
        model.addAttribute("pendingMembers", new ArrayList<>(members.findByExpiryDateIsNullOrderByIdDesc()));
        model.addAttribute("stats", dashboard.stats());
        model.addAttribute("expiringSoon", expiringSoon);
        return "dashboard";
    }
}
