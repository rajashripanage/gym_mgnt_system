package com.gym.controller;

import com.gym.model.*;
import com.gym.repository.*;
import com.gym.service.AttendanceService;
import com.gym.service.BillingService;
import com.gym.service.DashboardService;
import com.gym.service.MemberService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * REST API (JSON). Test with Postman using HTTP Basic auth (admin / admin123).
 */
@RestController
@RequestMapping("/api")
public class ApiController {

    private final MemberService memberService;
    private final TrainerRepository trainers;
    private final MembershipPlanRepository plans;
    private final AttendanceService attendanceService;
    private final BillingService billing;
    private final DashboardService dashboard;

    public ApiController(MemberService memberService, TrainerRepository trainers, MembershipPlanRepository plans,
                         AttendanceService attendanceService, BillingService billing, DashboardService dashboard) {
        this.memberService = memberService;
        this.trainers = trainers;
        this.plans = plans;
        this.attendanceService = attendanceService;
        this.billing = billing;
        this.dashboard = dashboard;
    }

    // ---- members ----
    @GetMapping("/members")
    public List<Member> members(@RequestParam(required = false) String q) { return memberService.search(q); }

    @GetMapping("/members/{id}")
    public Member member(@PathVariable Long id) { return memberService.get(id); }

    @PostMapping("/members")
    @ResponseStatus(HttpStatus.CREATED)
    public Member addMember(@Valid @RequestBody Member member,
                            @RequestParam(required = false) Long planId,
                            @RequestParam(required = false) Long trainerId) {
        member.setId(null);
        return memberService.save(member, planId, trainerId);
    }

    @PutMapping("/members/{id}/trainer")
    public Member assignTrainer(@PathVariable Long id, @RequestParam(required = false) Long trainerId) {
        return memberService.assignTrainer(id, trainerId);
    }

    @DeleteMapping("/members/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteMember(@PathVariable Long id) { memberService.delete(id); }

    // ---- trainers & plans ----
    @GetMapping("/trainers")
    public List<Trainer> trainers() { return trainers.findAll(); }

    @PostMapping("/trainers")
    @ResponseStatus(HttpStatus.CREATED)
    public Trainer addTrainer(@Valid @RequestBody Trainer trainer) {
        trainer.setId(null);
        return trainers.save(trainer);
    }

    @GetMapping("/plans")
    public List<MembershipPlan> plans() { return plans.findAll(); }

    @PostMapping("/plans")
    @ResponseStatus(HttpStatus.CREATED)
    public MembershipPlan addPlan(@Valid @RequestBody MembershipPlan plan) {
        plan.setId(null);
        return plans.save(plan);
    }

    // ---- attendance ----
    @GetMapping("/attendance")
    public List<Attendance> attendance(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return attendanceService.byDate(date == null ? LocalDate.now() : date);
    }

    @PostMapping("/attendance/{memberId}")
    @ResponseStatus(HttpStatus.CREATED)
    public Attendance mark(@PathVariable Long memberId) { return attendanceService.mark(memberId); }

    // ---- invoices & payments ----
    @GetMapping("/invoices")
    public List<Invoice> invoices() { return billing.allInvoices(); }

    @PostMapping("/invoices")
    @ResponseStatus(HttpStatus.CREATED)
    public Invoice generateInvoice(@RequestParam Long memberId, @RequestParam(required = false) Long planId) {
        return billing.generateInvoice(memberId, planId);
    }

    @GetMapping("/payments")
    public List<Payment> payments() { return billing.allPayments(); }

    @PostMapping("/payments")
    @ResponseStatus(HttpStatus.CREATED)
    public Payment pay(@RequestParam Long invoiceId, @RequestParam BigDecimal amount, @RequestParam PaymentMode mode,
                       @RequestParam(required = false) String reference) {
        return billing.addPayment(invoiceId, amount, mode, reference);
    }

    // ---- dashboard ----
    @GetMapping("/dashboard")
    public Map<String, Object> stats() { return dashboard.stats(); }
}
