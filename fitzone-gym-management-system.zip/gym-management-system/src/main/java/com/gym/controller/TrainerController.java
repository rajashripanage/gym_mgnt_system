package com.gym.controller;

import com.gym.model.Trainer;
import com.gym.repository.MemberRepository;
import com.gym.repository.TrainerRepository;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/trainers")
public class TrainerController {

    private final TrainerRepository repo;

    private final MemberRepository members;

    public TrainerController(TrainerRepository repo, MemberRepository members) {
        this.repo = repo;
        this.members = members;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("trainers", repo.findAll());
        model.addAttribute("trainer", new Trainer());
        java.util.Map<Long, Long> counts = new java.util.HashMap<>();
        repo.findAll().forEach(t -> counts.put(t.getId(), members.countByTrainerId(t.getId())));
        model.addAttribute("counts", counts);
        model.addAttribute("unassigned", members.countByTrainerIsNull());
        return "trainers";
    }

    /** Trainer page: all members assigned to this trainer. */
    @GetMapping("/{id}")
    public String view(@PathVariable Long id, Model model) {
        model.addAttribute("trainer", repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Trainer not found")));
        model.addAttribute("assigned", members.findByTrainerIdOrderByNameAsc(id));
        return "trainer-view";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("trainer") Trainer trainer, BindingResult result, RedirectAttributes ra) {
        if (result.hasErrors()) {
            ra.addFlashAttribute("error", result.getAllErrors().get(0).getDefaultMessage());
            return "redirect:/trainers";
        }
        try {
            repo.save(trainer);
            ra.addFlashAttribute("success", "Trainer saved");
        } catch (DataIntegrityViolationException e) {
            ra.addFlashAttribute("error", "Trainer email or phone already exists");
        }
        return "redirect:/trainers";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes ra) {
        try {
            repo.deleteById(id);
            ra.addFlashAttribute("success", "Trainer deleted");
        } catch (DataIntegrityViolationException e) {
            ra.addFlashAttribute("error", "Cannot delete: members are assigned to this trainer. Re-assign them first.");
        }
        return "redirect:/trainers";
    }
}
