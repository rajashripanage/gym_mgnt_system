package com.gym.controller;

import com.gym.repository.MemberRepository;
import com.gym.repository.MembershipPlanRepository;
import com.gym.repository.TrainerRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/** Public landing page of the gym. */
@Controller
public class HomeController {

    private final MembershipPlanRepository plans;
    private final TrainerRepository trainers;
    private final MemberRepository members;

    public HomeController(MembershipPlanRepository plans, TrainerRepository trainers, MemberRepository members) {
        this.plans = plans;
        this.trainers = trainers;
        this.members = members;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("plans", plans.findAll());
        model.addAttribute("trainers", trainers.findAll());
        model.addAttribute("memberCount", members.count());
        model.addAttribute("trainerCount", trainers.count());
        return "home";
    }
}
