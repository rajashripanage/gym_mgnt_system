package com.gym.exception;

/** Thrown when a unique value (email / phone / attendance) already exists. */
public class DuplicateException extends RuntimeException {
    public DuplicateException(String message) { super(message); }
}
