package com.gym.repository;

import com.gym.model.Member;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Long> {
    Optional<Member> findByEmail(String email);
    Optional<Member> findByPhone(String phone);
    List<Member> findByNameContainingIgnoreCaseOrPhoneContaining(String name, String phone);
    List<Member> findByActiveTrueOrderByNameAsc();
    List<Member> findByExpiryDateBetween(LocalDate from, LocalDate to);
    List<Member> findByExpiryDateIsNullOrderByIdDesc();
    long countByActiveTrue();
    long countByTrainerIsNull();
    List<Member> findByTrainerIdOrderByNameAsc(Long trainerId);
    long countByTrainerId(Long trainerId);
    List<Member> findByExpiryDateBeforeOrderByExpiryDateDesc(LocalDate date);
    long countByExpiryDateBefore(LocalDate date);
}
