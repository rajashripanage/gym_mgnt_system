package com.gym.repository;

import com.gym.model.Notification;
import com.gym.model.NotificationAudience;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findTop50ByAudienceOrderByIdDesc(NotificationAudience audience);
    List<Notification> findTop50ByAudienceAndMemberIdOrderByIdDesc(NotificationAudience audience, Long memberId);
    List<Notification> findByAudienceAndSeenFalse(NotificationAudience audience);
    List<Notification> findByAudienceAndMemberIdAndSeenFalse(NotificationAudience audience, Long memberId);
    long countByAudienceAndSeenFalse(NotificationAudience audience);
    long countByAudienceAndMemberIdAndSeenFalse(NotificationAudience audience, Long memberId);
    void deleteByMemberId(Long memberId);
}
