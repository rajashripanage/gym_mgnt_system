package com.gym.repository;

import com.gym.model.QueryStatus;
import com.gym.model.SupportQuery;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SupportQueryRepository extends JpaRepository<SupportQuery, Long> {
    List<SupportQuery> findAllByOrderByUpdatedAtDesc();
    List<SupportQuery> findByMemberIdOrderByUpdatedAtDesc(Long memberId);
    long countByStatus(QueryStatus status);
    void deleteByMemberId(Long memberId);
}
