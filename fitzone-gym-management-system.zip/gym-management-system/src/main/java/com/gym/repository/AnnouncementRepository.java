package com.gym.repository;

import com.gym.model.Announcement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AnnouncementRepository extends JpaRepository<Announcement, Long> {
    List<Announcement> findTop5ByOrderByIdDesc();
    List<Announcement> findAllByOrderByIdDesc();
}
