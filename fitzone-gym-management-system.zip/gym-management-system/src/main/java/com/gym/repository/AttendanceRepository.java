package com.gym.repository;

import com.gym.model.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByAttendanceDateOrderByCheckInTimeDesc(LocalDate date);
    boolean existsByMemberIdAndAttendanceDate(Long memberId, LocalDate date);
    List<Attendance> findTop30ByMemberIdOrderByAttendanceDateDesc(Long memberId);
    long countByAttendanceDate(LocalDate date);
    long countByMemberIdAndAttendanceDateBetween(Long memberId, LocalDate from, LocalDate to);
    long countByMemberId(Long memberId);
    java.util.Optional<Attendance> findByMemberIdAndAttendanceDate(Long memberId, LocalDate date);
}
