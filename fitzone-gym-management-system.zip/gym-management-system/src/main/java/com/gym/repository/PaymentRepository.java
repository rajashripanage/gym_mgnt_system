package com.gym.repository;

import com.gym.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findAllByOrderByIdDesc();
    List<Payment> findByInvoiceIdOrderByIdDesc(Long invoiceId);

    List<Payment> findByInvoiceMemberIdOrderByIdDesc(Long memberId);

    @Query("select sum(p.amount) from Payment p where p.paymentDate = :date")
    BigDecimal sumAmountOn(@org.springframework.data.repository.query.Param("date") java.time.LocalDate date);

    default BigDecimal collectedOn(java.time.LocalDate date) {
        BigDecimal total = sumAmountOn(date);
        return total == null ? BigDecimal.ZERO : total;
    }

    @Query("select sum(p.amount) from Payment p")
    BigDecimal sumAmount();

    default BigDecimal totalRevenue() {
        BigDecimal total = sumAmount();
        return total == null ? BigDecimal.ZERO : total;
    }
}
