package com.gym.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "trainers")
public class Trainer extends User {

    private String specialization;

    @Min(value = 0, message = "Experience cannot be negative")
    private int experienceYears;

    @Override
    public String getRole() { return "TRAINER"; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    public int getExperienceYears() { return experienceYears; }
    public void setExperienceYears(int experienceYears) { this.experienceYears = experienceYears; }
}
