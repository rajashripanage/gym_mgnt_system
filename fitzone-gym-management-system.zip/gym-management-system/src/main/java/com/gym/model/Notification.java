package com.gym.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/** In-app notification. audience=ADMIN -> shown to the owner; audience=MEMBER -> shown to that member only. */
@Entity
@Table(name = "notifications")
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private NotificationAudience audience;

    /** Only used when audience = MEMBER. */
    @ManyToOne
    private Member member;

    private String title;

    @Column(length = 1000)
    private String message;

    /** Page to open when the notification is clicked (optional). */
    private String link;

    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "is_seen")
    private boolean seen;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public NotificationAudience getAudience() { return audience; }
    public void setAudience(NotificationAudience audience) { this.audience = audience; }
    public Member getMember() { return member; }
    public void setMember(Member member) { this.member = member; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public boolean isSeen() { return seen; }
    public void setSeen(boolean seen) { this.seen = seen; }
}
