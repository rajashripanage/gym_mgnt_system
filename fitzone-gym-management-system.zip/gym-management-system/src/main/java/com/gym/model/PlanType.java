package com.gym.model;

public enum PlanType { BASIC, PREMIUM, VIP }
