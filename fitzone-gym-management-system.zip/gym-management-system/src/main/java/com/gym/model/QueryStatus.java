package com.gym.model;

public enum QueryStatus { OPEN, ANSWERED, CLOSED }
