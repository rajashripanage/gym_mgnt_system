package com.gym.model;

public enum PaymentMode { CASH, UPI, CARD, NET_BANKING }
