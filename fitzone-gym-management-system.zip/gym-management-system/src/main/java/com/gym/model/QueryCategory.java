package com.gym.model;

public enum QueryCategory {
    GENERAL("General"), PAYMENT("Payment / Invoice"), TRAINER("Trainer"),
    PLAN("Plan / Renewal"), ATTENDANCE("Attendance"), OTHER("Other");

    private final String label;
    QueryCategory(String label) { this.label = label; }
    public String getLabel() { return label; }
}
