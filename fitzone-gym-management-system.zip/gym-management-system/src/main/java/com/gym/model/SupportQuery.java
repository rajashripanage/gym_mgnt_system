package com.gym.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** A question / complaint raised by a member from his profile. The owner replies in the same thread. */
@Entity
@Table(name = "support_queries")
public class SupportQuery {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Member member;

    private String subject;

    @Enumerated(EnumType.STRING)
    private QueryCategory category = QueryCategory.GENERAL;

    @Enumerated(EnumType.STRING)
    private QueryStatus status = QueryStatus.OPEN;

    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime updatedAt = LocalDateTime.now();

    @OneToMany(mappedBy = "query", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("id ASC")
    private List<QueryMessage> messages = new ArrayList<>();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Member getMember() { return member; }
    public void setMember(Member member) { this.member = member; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public QueryCategory getCategory() { return category; }
    public void setCategory(QueryCategory category) { this.category = category; }
    public QueryStatus getStatus() { return status; }
    public void setStatus(QueryStatus status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    public List<QueryMessage> getMessages() { return messages; }
    public void setMessages(List<QueryMessage> messages) { this.messages = messages; }
}
