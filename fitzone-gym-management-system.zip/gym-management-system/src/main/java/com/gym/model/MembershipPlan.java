package com.gym.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

@Entity
@Table(name = "membership_plans")
public class MembershipPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Plan name is required")
    @Column(unique = true, nullable = false)
    private String name;

    @NotNull(message = "Plan type is required")
    @Enumerated(EnumType.STRING)
    private PlanType type;

    @Min(value = 1, message = "Duration must be at least 1 month")
    private int durationMonths;

    @NotNull(message = "Price is required")
    @DecimalMin(value = "1", message = "Price must be positive")
    @Column(precision = 10, scale = 2)
    private BigDecimal price;

    private String description;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public PlanType getType() { return type; }
    public void setType(PlanType type) { this.type = type; }
    public int getDurationMonths() { return durationMonths; }
    public void setDurationMonths(int durationMonths) { this.durationMonths = durationMonths; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
