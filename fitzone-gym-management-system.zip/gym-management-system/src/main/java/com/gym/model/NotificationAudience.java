package com.gym.model;

/** Who should see a notification: the gym owner (ADMIN) or one particular member. */
public enum NotificationAudience { ADMIN, MEMBER }
