package com.gym.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/** One message inside a query thread (written by the member or by the owner). */
@Entity
@Table(name = "query_messages")
public class QueryMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private SupportQuery query;

    /** "MEMBER" or "OWNER" */
    private String sender;

    @Column(length = 2000)
    private String text;

    private LocalDateTime createdAt = LocalDateTime.now();

    public boolean isFromOwner() { return "OWNER".equals(sender); }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public SupportQuery getQuery() { return query; }
    public void setQuery(SupportQuery query) { this.query = query; }
    public String getSender() { return sender; }
    public void setSender(String sender) { this.sender = sender; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
