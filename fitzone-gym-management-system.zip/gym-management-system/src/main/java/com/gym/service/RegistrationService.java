package com.gym.service;

import com.gym.dto.RegisterForm;
import com.gym.exception.DuplicateException;
import com.gym.model.Member;
import com.gym.model.MembershipPlan;
import com.gym.model.UserAccount;
import com.gym.repository.MemberRepository;
import com.gym.repository.MembershipPlanRepository;
import com.gym.repository.UserAccountRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
public class RegistrationService {

    private final UserAccountRepository accounts;
    private final MemberRepository members;
    private final MembershipPlanRepository plans;
    private final PasswordEncoder encoder;
    private final NotificationService notifications;

    public RegistrationService(UserAccountRepository accounts, MemberRepository members,
                               MembershipPlanRepository plans, PasswordEncoder encoder,
                               NotificationService notifications) {
        this.notifications = notifications;
        this.accounts = accounts;
        this.members = members;
        this.plans = plans;
        this.encoder = encoder;
    }

    /** Public sign-up: creates the member profile + a login account (role MEMBER). */
    @Transactional
    public UserAccount register(RegisterForm form) {
        if (!form.getPassword().equals(form.getConfirmPassword())) {
            throw new IllegalArgumentException("Passwords do not match");
        }
        String email = form.getEmail().trim().toLowerCase();
        if (accounts.existsByEmailIgnoreCase(email) || accounts.existsByUsernameIgnoreCase(email)
                || members.findByEmail(email).isPresent()) {
            throw new DuplicateException("An account with this email already exists. Please login.");
        }
        if (members.findByPhone(form.getPhone()).isPresent()) {
            throw new DuplicateException("This phone number is already registered");
        }
        MembershipPlan plan = form.getPlanId() == null ? null : plans.findById(form.getPlanId()).orElse(null);

        Member m = new Member();
        m.setName(form.getFullName().trim());
        m.setEmail(email);
        m.setPhone(form.getPhone());
        m.setGender(form.getGender());
        m.setAddress(blankToNull(form.getAddress()));
        m.setEmergencyContact(blankToNull(form.getEmergencyContact()));
        m.setFitnessGoal(blankToNull(form.getFitnessGoal()));
        m.setPlan(plan);
        m.setJoinDate(LocalDate.now());
        m.setActive(true);          // expiry stays empty = "Pending" until the gym desk generates the first invoice
        m = members.save(m);

        UserAccount acc = new UserAccount();
        acc.setUsername(email);
        acc.setEmail(email);
        acc.setFullName(m.getName());
        acc.setPassword(encoder.encode(form.getPassword()));
        acc.setRole("MEMBER");
        acc.setEnabled(true);
        acc.setMember(m);
        acc = accounts.save(acc);

        // tell the owner: from here the owner assigns trainer, generates invoice, records payment...
        notifications.notifyOwner("New member registered: " + m.getName(),
                m.getName() + " (" + m.getPhone() + ")"
                        + (plan != null ? " selected " + plan.getName() : " has not selected a plan")
                        + ". Assign a trainer and generate the first invoice.",
                "/members/" + m.getId());
        notifications.notifyMember(m, "Welcome to FitZone!",
                "Your registration is received. The gym owner will assign your trainer and activate your membership. "
                + "If you have any question, use the Queries section.", "/portal");
        return acc;
    }

    private static String blankToNull(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }
}
