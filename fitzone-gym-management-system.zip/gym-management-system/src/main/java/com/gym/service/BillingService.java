package com.gym.service;

import com.gym.fee.FeeCalculator;
import com.gym.fee.FeeCalculatorFactory;
import com.gym.model.*;
import com.gym.repository.InvoiceRepository;
import com.gym.repository.MemberRepository;
import com.gym.repository.MembershipPlanRepository;
import com.gym.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

@Service
public class BillingService {

    private static final BigDecimal GST_RATE = new BigDecimal("0.18");
    private static final int DEFAULT_DUE_DAYS = 7;

    private final InvoiceRepository invoices;
    private final PaymentRepository payments;
    private final MemberRepository members;
    private final MembershipPlanRepository plans;
    private final NotificationService notifications;

    public BillingService(InvoiceRepository invoices, PaymentRepository payments,
                          MemberRepository members, MembershipPlanRepository plans,
                          NotificationService notifications) {
        this.invoices = invoices;
        this.payments = payments;
        this.members = members;
        this.plans = plans;
        this.notifications = notifications;
    }

    // ---------------- reads ----------------
    public List<Invoice> allInvoices() { return invoices.findAllByOrderByIdDesc(); }

    public List<Payment> allPayments() { return payments.findAllByOrderByIdDesc(); }

    public List<Payment> paymentsOf(Long invoiceId) { return payments.findByInvoiceIdOrderByIdDesc(invoiceId); }

    public List<Invoice> invoicesOfMember(Long memberId) { return invoices.findByMemberIdOrderByIdDesc(memberId); }

    public List<Payment> paymentsOfMember(Long memberId) { return payments.findByInvoiceMemberIdOrderByIdDesc(memberId); }

    public Invoice getInvoice(Long id) {
        return invoices.findById(id).orElseThrow(() -> new IllegalArgumentException("Invoice not found"));
    }

    public Payment getPayment(Long id) {
        return payments.findById(id).orElseThrow(() -> new IllegalArgumentException("Payment not found"));
    }

    /** Member portal: a member can open only his own invoices. */
    public Invoice getInvoiceForMember(Long id, Long memberId) {
        Invoice inv = getInvoice(id);
        if (!inv.getMember().getId().equals(memberId)) throw new IllegalArgumentException("Invoice not found");
        return inv;
    }

    /** Member portal: a member can open only his own receipts. */
    public Payment getPaymentForMember(Long id, Long memberId) {
        Payment p = getPayment(id);
        if (!p.getInvoice().getMember().getId().equals(memberId)) throw new IllegalArgumentException("Receipt not found");
        return p;
    }

    public List<Invoice> unpaidInvoices() {
        return invoices.findAllByOrderByIdDesc().stream().filter(i -> i.getBalance().signum() > 0).toList();
    }

    public List<Invoice> overdueInvoices() {
        return unpaidInvoices().stream().filter(Invoice::isOverdue).toList();
    }

    public BigDecimal dueOfMember(Long memberId) {
        return invoices.findByMemberIdOrderByIdDesc(memberId).stream()
                .map(Invoice::getBalance)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    // ---------------- invoice ----------------
    public Invoice generateInvoice(Long memberId, Long planId) {
        return generateInvoice(memberId, planId, null, null, null);
    }

    /**
     * Generates a bill: base price - plan-type discount - extra discount + 18% GST. Also renews the membership.
     * extraDiscount / dueDate / notes are optional.
     */
    @Transactional
    public Invoice generateInvoice(Long memberId, Long planId, BigDecimal extraDiscount, LocalDate dueDate, String notes) {
        Member member = members.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Member not found"));
        MembershipPlan plan = (planId != null)
                ? plans.findById(planId).orElseThrow(() -> new IllegalArgumentException("Plan not found"))
                : member.getPlan();
        if (plan == null) {
            throw new IllegalArgumentException("Select a plan - this member has no plan assigned");
        }
        boolean firstInvoice = member.isPending();

        FeeCalculator calculator = FeeCalculatorFactory.forType(plan.getType());   // polymorphism
        BigDecimal base = plan.getPrice().setScale(2, RoundingMode.HALF_UP);
        BigDecimal typeDiscount = calculator.calculateDiscount(base);

        BigDecimal extra = (extraDiscount == null) ? BigDecimal.ZERO : extraDiscount.setScale(2, RoundingMode.HALF_UP);
        if (extra.signum() < 0) {
            throw new IllegalArgumentException("Extra discount cannot be negative");
        }
        if (extra.compareTo(base.subtract(typeDiscount)) > 0) {
            throw new IllegalArgumentException("Extra discount cannot be more than the plan price");
        }
        BigDecimal discount = typeDiscount.add(extra);
        BigDecimal taxable = base.subtract(discount);
        BigDecimal tax = taxable.multiply(GST_RATE).setScale(2, RoundingMode.HALF_UP);

        Invoice inv = new Invoice();
        inv.setInvoiceNumber("TMP-" + System.nanoTime());
        inv.setMember(member);
        inv.setPlan(plan);
        inv.setBaseAmount(base);
        inv.setDiscount(discount);
        inv.setExtraDiscount(extra);
        inv.setTax(tax);
        inv.setTotalAmount(taxable.add(tax));
        inv.setPaidAmount(BigDecimal.ZERO);
        inv.setInvoiceDate(LocalDate.now());
        inv.setDueDate(dueDate != null ? dueDate : LocalDate.now().plusDays(DEFAULT_DUE_DAYS));
        inv.setNotes(notes == null || notes.isBlank() ? null : notes.trim());
        inv = invoices.save(inv);
        inv.setInvoiceNumber(String.format("INV-%05d", inv.getId()));

        // renew membership
        LocalDate today = LocalDate.now();
        LocalDate start = (member.getExpiryDate() != null && member.getExpiryDate().isAfter(today))
                ? member.getExpiryDate() : today;
        member.setPlan(plan);
        member.setExpiryDate(start.plusMonths(plan.getDurationMonths()));
        member.setActive(true);
        members.save(member);

        notifications.notifyMember(member,
                firstInvoice ? "Membership started" : "Membership renewed",
                "Invoice " + inv.getInvoiceNumber() + " of Rs. " + inv.getTotalAmount() + " generated for " + plan.getName()
                        + ". Valid till " + member.getExpiryDate() + ".",
                "/portal/invoices/" + inv.getId());
        return inv;
    }

    // ---------------- payment ----------------
    public Payment addPayment(Long invoiceId, BigDecimal amount, PaymentMode mode) {
        return addPayment(invoiceId, amount, mode, null);
    }

    @Transactional
    public Payment addPayment(Long invoiceId, BigDecimal amount, PaymentMode mode, String reference) {
        Invoice inv = getInvoice(invoiceId);
        if (amount == null || amount.signum() <= 0) {
            throw new IllegalArgumentException("Amount must be greater than 0");
        }
        if (mode == null) {
            throw new IllegalArgumentException("Select a payment mode");
        }
        if (amount.compareTo(inv.getBalance()) > 0) {
            throw new IllegalArgumentException("Amount is more than the pending balance (" + inv.getBalance() + ")");
        }
        Payment p = new Payment();
        p.setInvoice(inv);
        p.setAmount(amount.setScale(2, RoundingMode.HALF_UP));
        p.setPaymentMode(mode);
        p.setPaymentDate(LocalDate.now());
        p.setReference(reference == null || reference.isBlank() ? null : reference.trim());
        p = payments.save(p);
        p.setReceiptNumber(String.format("RCPT-%05d", p.getId()));
        payments.save(p);

        inv.setPaidAmount(inv.getPaidAmount().add(p.getAmount()));
        invoices.save(inv);

        boolean cleared = inv.getBalance().signum() <= 0;
        notifications.notifyMember(inv.getMember(), "Payment received",
                "Rs. " + p.getAmount() + " received via " + mode + " (" + p.getReceiptNumber() + ")."
                        + (cleared ? " Invoice " + inv.getInvoiceNumber() + " is fully paid." : " Balance: Rs. " + inv.getBalance()),
                "/portal/receipts/" + p.getId());
        return p;
    }
}
