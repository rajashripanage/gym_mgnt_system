package com.gym.service;

import com.gym.exception.DuplicateException;
import com.gym.model.Member;
import com.gym.model.MembershipPlan;
import com.gym.model.Trainer;
import com.gym.model.UserAccount;
import com.gym.repository.MemberRepository;
import com.gym.repository.MembershipPlanRepository;
import com.gym.repository.PasswordResetTokenRepository;
import com.gym.repository.TrainerRepository;
import com.gym.repository.UserAccountRepository;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class MemberService {

    private final MemberRepository members;
    private final MembershipPlanRepository plans;
    private final TrainerRepository trainers;
    private final UserAccountRepository accounts;
    private final PasswordResetTokenRepository tokens;
    private final PasswordEncoder encoder;
    private final NotificationService notifications;
    private final QueryService queries;

    public MemberService(MemberRepository members, MembershipPlanRepository plans, TrainerRepository trainers,
                         UserAccountRepository accounts, PasswordResetTokenRepository tokens,
                         PasswordEncoder encoder, NotificationService notifications, QueryService queries) {
        this.accounts = accounts;
        this.tokens = tokens;
        this.members = members;
        this.plans = plans;
        this.trainers = trainers;
        this.encoder = encoder;
        this.notifications = notifications;
        this.queries = queries;
    }

    public List<Member> search(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return members.findAll(Sort.by(Sort.Direction.DESC, "id"));
        }
        String k = keyword.trim();
        return members.findByNameContainingIgnoreCaseOrPhoneContaining(k, k);
    }

    public Member get(Long id) {
        return members.findById(id).orElseThrow(() -> new IllegalArgumentException("Member not found: " + id));
    }

    /** Creates or updates a member and assigns plan + trainer. */
    @Transactional
    public Member save(Member member, Long planId, Long trainerId) {
        // duplicate checks (the database also has UNIQUE constraints as a second safety net)
        members.findByEmail(member.getEmail())
               .filter(other -> !Objects.equals(other.getId(), member.getId()))
               .ifPresent(o -> { throw new DuplicateException("A member with this email already exists"); });
        members.findByPhone(member.getPhone())
               .filter(other -> !Objects.equals(other.getId(), member.getId()))
               .ifPresent(o -> { throw new DuplicateException("A member with this phone number already exists"); });

        MembershipPlan plan = planId == null ? null
                : plans.findById(planId).orElseThrow(() -> new IllegalArgumentException("Plan not found"));
        Trainer trainer = trainerId == null ? null
                : trainers.findById(trainerId).orElseThrow(() -> new IllegalArgumentException("Trainer not found"));

        member.setPlan(plan);
        member.setTrainer(trainer);
        if (member.getJoinDate() == null) {
            member.setJoinDate(LocalDate.now());
        }
        if (member.getExpiryDate() == null && plan != null) {
            member.setExpiryDate(member.getJoinDate().plusMonths(plan.getDurationMonths()));
        }
        Member saved = members.save(member);
        syncAccount(saved);
        return saved;
    }

    /** Keeps the login account in step when the owner edits the member's name / email. */
    private void syncAccount(Member m) {
        accounts.findByMemberId(m.getId()).ifPresent(acc -> {
            acc.setFullName(m.getName());
            String email = m.getEmail().trim().toLowerCase();
            if (!acc.getEmail().equalsIgnoreCase(email)) {
                Optional<UserAccount> clash = accounts.findByEmailIgnoreCase(email);
                if (clash.isPresent() && !clash.get().getId().equals(acc.getId())) {
                    throw new DuplicateException("This email is already used by another login account");
                }
                acc.setEmail(email);
                acc.setUsername(email);
            }
            accounts.save(acc);
        });
    }

    // ------------------------------------------------------------------
    //  Owner actions on a member
    // ------------------------------------------------------------------

    /** Assign (or remove, when trainerId is null) the trainer of a member and tell the member. */
    @Transactional
    public Member assignTrainer(Long memberId, Long trainerId) {
        Member m = get(memberId);
        if (trainerId == null) {
            m.setTrainer(null);
            notifications.notifyMember(m, "Trainer changed", "Your trainer assignment has been removed. "
                    + "The owner will assign a new trainer soon.", "/portal");
        } else {
            Trainer t = trainers.findById(trainerId).orElseThrow(() -> new IllegalArgumentException("Trainer not found"));
            m.setTrainer(t);
            notifications.notifyMember(m, "Trainer assigned",
                    t.getName() + " (" + (t.getSpecialization() == null ? "Trainer" : t.getSpecialization())
                            + ") is now your trainer.", "/portal");
        }
        return members.save(m);
    }

    /** Change the plan chosen by the member (the dates change only when an invoice is generated). */
    @Transactional
    public Member assignPlan(Long memberId, Long planId) {
        Member m = get(memberId);
        MembershipPlan plan = planId == null ? null
                : plans.findById(planId).orElseThrow(() -> new IllegalArgumentException("Plan not found"));
        m.setPlan(plan);
        return members.save(m);
    }

    @Transactional
    public Member setActive(Long memberId, boolean active) {
        Member m = get(memberId);
        m.setActive(active);
        notifications.notifyMember(m, active ? "Account activated" : "Account deactivated",
                active ? "Your gym account is active again." : "Your gym account has been deactivated. Contact the owner for details.",
                "/portal");
        return members.save(m);
    }

    @Transactional
    public Member saveOwnerNotes(Long memberId, String notes) {
        Member m = get(memberId);
        m.setOwnerNotes(notes == null || notes.isBlank() ? null : notes.trim());
        return members.save(m);
    }

    // ------------------------------------------------------------------
    //  Member self-service (profile page of the logged-in member)
    // ------------------------------------------------------------------

    @Transactional
    public Member updateOwnProfile(Long memberId, String name, String phone, String address,
                                   LocalDate dateOfBirth, String emergencyContact, String fitnessGoal, String gender) {
        Member m = get(memberId);
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name is required");
        if (phone == null || !phone.matches("\\d{10}")) throw new IllegalArgumentException("Phone must be 10 digits");
        members.findByPhone(phone)
               .filter(other -> !Objects.equals(other.getId(), memberId))
               .ifPresent(o -> { throw new DuplicateException("This phone number is already registered"); });

        boolean phoneChanged = !phone.equals(m.getPhone());
        m.setName(name.trim());
        m.setPhone(phone);
        m.setGender(gender);
        m.setAddress(address == null || address.isBlank() ? null : address.trim());
        m.setDateOfBirth(dateOfBirth);
        m.setEmergencyContact(emergencyContact == null || emergencyContact.isBlank() ? null : emergencyContact.trim());
        m.setFitnessGoal(fitnessGoal == null || fitnessGoal.isBlank() ? null : fitnessGoal.trim());
        m = members.save(m);
        syncAccount(m);
        if (phoneChanged) {
            notifications.notifyOwner(m.getName() + " changed phone number", "New number: " + phone, "/members/" + m.getId());
        }
        return m;
    }

    @Transactional
    public void changePassword(Long memberId, String current, String newPassword, String confirm) {
        UserAccount acc = accounts.findByMemberId(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Login account not found"));
        if (current == null || !encoder.matches(current, acc.getPassword())) {
            throw new IllegalArgumentException("Current password is wrong");
        }
        if (newPassword == null || newPassword.length() < 6) {
            throw new IllegalArgumentException("New password must be at least 6 characters");
        }
        if (!newPassword.equals(confirm)) {
            throw new IllegalArgumentException("New passwords do not match");
        }
        acc.setPassword(encoder.encode(newPassword));
        accounts.save(acc);
    }

    // ------------------------------------------------------------------

    @Transactional
    public void delete(Long id) {
        queries.deleteForMember(id);
        notifications.deleteForMember(id);
        accounts.findByMemberId(id).ifPresent(acc -> {
            tokens.deleteByUserId(acc.getId());
            accounts.delete(acc);
        });
        members.deleteById(id);
    }
}
