package com.gym.service;

import com.gym.model.Member;
import com.gym.model.Notification;
import com.gym.model.NotificationAudience;
import com.gym.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** Creates and reads in-app notifications for the owner and for members. */
@Service
public class NotificationService {

    private final NotificationRepository repo;

    public NotificationService(NotificationRepository repo) {
        this.repo = repo;
    }

    // ---------- create ----------
    public void notifyOwner(String title, String message, String link) {
        Notification n = new Notification();
        n.setAudience(NotificationAudience.ADMIN);
        n.setTitle(cut(title, 250));
        n.setMessage(cut(message, 1000));
        n.setLink(link);
        repo.save(n);
    }

    public void notifyMember(Member member, String title, String message, String link) {
        if (member == null) return;
        Notification n = new Notification();
        n.setAudience(NotificationAudience.MEMBER);
        n.setMember(member);
        n.setTitle(cut(title, 250));
        n.setMessage(cut(message, 1000));
        n.setLink(link);
        repo.save(n);
    }

    private static String cut(String s, int max) {
        return (s == null || s.length() <= max) ? s : s.substring(0, max - 3) + "...";
    }

    // ---------- owner ----------
    public List<Notification> ownerList() {
        return repo.findTop50ByAudienceOrderByIdDesc(NotificationAudience.ADMIN);
    }

    public long ownerUnread() {
        return repo.countByAudienceAndSeenFalse(NotificationAudience.ADMIN);
    }

    @Transactional
    public void markAllOwnerRead() {
        List<Notification> list = repo.findByAudienceAndSeenFalse(NotificationAudience.ADMIN);
        list.forEach(n -> n.setSeen(true));
        repo.saveAll(list);
    }

    // ---------- member ----------
    public List<Notification> memberList(Long memberId) {
        return repo.findTop50ByAudienceAndMemberIdOrderByIdDesc(NotificationAudience.MEMBER, memberId);
    }

    public long memberUnread(Long memberId) {
        return repo.countByAudienceAndMemberIdAndSeenFalse(NotificationAudience.MEMBER, memberId);
    }

    @Transactional
    public void markAllMemberRead(Long memberId) {
        List<Notification> list = repo.findByAudienceAndMemberIdAndSeenFalse(NotificationAudience.MEMBER, memberId);
        list.forEach(n -> n.setSeen(true));
        repo.saveAll(list);
    }

    // ---------- single ----------
    /** Marks one notification as read and returns it (so the controller can redirect to its link). */
    @Transactional
    public Notification open(Long id) {
        Notification n = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Notification not found"));
        n.setSeen(true);
        return repo.save(n);
    }

    @Transactional
    public void deleteForMember(Long memberId) {
        repo.deleteByMemberId(memberId);
    }
}
