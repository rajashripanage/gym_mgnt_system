package com.gym.service;

import com.gym.model.UserAccount;
import com.gym.repository.UserAccountRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/** Loads login users (ADMIN / MEMBER) from the database. Login works with username or email. */
@Service
public class AccountUserDetailsService implements UserDetailsService {

    private final UserAccountRepository accounts;

    public AccountUserDetailsService(UserAccountRepository accounts) {
        this.accounts = accounts;
    }

    @Override
    public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
        String id = login.trim();
        UserAccount a = accounts.findByUsernameIgnoreCaseOrEmailIgnoreCase(id, id)
                .orElseThrow(() -> new UsernameNotFoundException("No account found: " + id));
        return org.springframework.security.core.userdetails.User
                .withUsername(a.getUsername())
                .password(a.getPassword())
                .roles(a.getRole())
                .disabled(!a.isEnabled())
                .build();
    }
}
