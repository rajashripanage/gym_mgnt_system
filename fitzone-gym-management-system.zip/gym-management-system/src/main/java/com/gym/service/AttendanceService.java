package com.gym.service;

import com.gym.exception.DuplicateException;
import com.gym.model.Attendance;
import com.gym.model.Member;
import com.gym.repository.AttendanceRepository;
import com.gym.repository.MemberRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
public class AttendanceService {

    private final AttendanceRepository attendanceRepo;
    private final MemberRepository memberRepo;

    public AttendanceService(AttendanceRepository attendanceRepo, MemberRepository memberRepo) {
        this.attendanceRepo = attendanceRepo;
        this.memberRepo = memberRepo;
    }

    public List<Attendance> byDate(LocalDate date) {
        return attendanceRepo.findByAttendanceDateOrderByCheckInTimeDesc(date);
    }

    public List<Attendance> recentOf(Long memberId) {
        return attendanceRepo.findTop30ByMemberIdOrderByAttendanceDateDesc(memberId);
    }

    /** Number of visits of a member in the current month. */
    public long visitsThisMonth(Long memberId) {
        LocalDate today = LocalDate.now();
        return attendanceRepo.countByMemberIdAndAttendanceDateBetween(memberId, today.withDayOfMonth(1), today);
    }

    public long totalVisits(Long memberId) {
        return attendanceRepo.countByMemberId(memberId);
    }

    public Attendance mark(Long memberId) {
        Member member = memberRepo.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Member not found"));
        LocalDate today = LocalDate.now();

        if (!member.isActive()) {
            throw new IllegalArgumentException(member.getName() + " is inactive");
        }
        if (member.isPending()) {
            throw new IllegalArgumentException(member.getName() + "'s membership has not started. Generate an invoice first.");
        }
        if (member.isExpired()) {
            throw new IllegalArgumentException("Membership of " + member.getName()
                    + " expired on " + member.getExpiryDate() + ". Please renew (generate invoice).");
        }
        if (attendanceRepo.existsByMemberIdAndAttendanceDate(memberId, today)) {
            throw new DuplicateException("Attendance of " + member.getName() + " is already marked today");
        }
        Attendance a = new Attendance();
        a.setMember(member);
        a.setAttendanceDate(today);
        a.setCheckInTime(LocalTime.now().withNano(0));
        return attendanceRepo.save(a);
    }

    /** Records the time the member left the gym. */
    public Attendance checkOut(Long attendanceId) {
        Attendance a = attendanceRepo.findById(attendanceId)
                .orElseThrow(() -> new IllegalArgumentException("Attendance record not found"));
        if (a.getCheckOutTime() != null) {
            throw new DuplicateException(a.getMember().getName() + " is already checked out");
        }
        LocalTime now = LocalTime.now().withNano(0);
        // an old record (other day) cannot be checked out with the current time
        a.setCheckOutTime(a.getAttendanceDate().equals(LocalDate.now()) ? now : a.getCheckInTime());
        return attendanceRepo.save(a);
    }
}
