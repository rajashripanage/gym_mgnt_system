package com.gym.service;

import com.gym.model.PasswordResetToken;
import com.gym.model.UserAccount;
import com.gym.repository.PasswordResetTokenRepository;
import com.gym.repository.UserAccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class PasswordResetService {

    private static final Logger log = LoggerFactory.getLogger(PasswordResetService.class);

    private final UserAccountRepository accounts;
    private final PasswordResetTokenRepository tokens;
    private final PasswordEncoder encoder;
    private final ObjectProvider<JavaMailSender> mailSender;

    @Value("${gym.mail.from:no-reply@fitzone.com}")
    private String mailFrom;

    public PasswordResetService(UserAccountRepository accounts, PasswordResetTokenRepository tokens,
                                PasswordEncoder encoder, ObjectProvider<JavaMailSender> mailSender) {
        this.accounts = accounts;
        this.tokens = tokens;
        this.encoder = encoder;
        this.mailSender = mailSender;
    }

    /** True when SMTP is configured in application.properties (spring.mail.host). */
    public boolean isMailEnabled() {
        return mailSender.getIfAvailable() != null;
    }

    /** Creates a 30-minute reset token. Returns the reset link if the email belongs to an account. */
    @Transactional
    public Optional<String> requestReset(String email, String baseUrl) {
        Optional<UserAccount> found = accounts.findByEmailIgnoreCase(email == null ? "" : email.trim());
        if (found.isEmpty()) {
            return Optional.empty();
        }
        UserAccount acc = found.get();
        tokens.deleteByUserId(acc.getId());          // old links stop working

        PasswordResetToken t = new PasswordResetToken();
        t.setToken(UUID.randomUUID().toString());
        t.setUser(acc);
        t.setExpiresAt(LocalDateTime.now().plusMinutes(30));
        t.setUsed(false);
        tokens.save(t);

        String link = baseUrl + "/reset-password?token=" + t.getToken();
        JavaMailSender sender = mailSender.getIfAvailable();
        if (sender != null) {
            try {
                SimpleMailMessage msg = new SimpleMailMessage();
                msg.setFrom(mailFrom);
                msg.setTo(acc.getEmail());
                msg.setSubject("FitZone Gym - Reset your password");
                msg.setText("Hello " + acc.getFullName() + ",\n\nClick the link below to reset your password "
                        + "(valid for 30 minutes):\n" + link + "\n\nIf you did not request this, ignore this email.");
                sender.send(msg);
            } catch (Exception e) {
                log.warn("Could not send reset email: {}", e.getMessage());
            }
        }
        log.info("Password reset link for {} : {}", acc.getEmail(), link);
        return Optional.of(link);
    }

    public boolean isTokenValid(String token) {
        return token != null && tokens.findByToken(token)
                .filter(t -> !t.isUsed() && !t.isExpired()).isPresent();
    }

    @Transactional
    public void resetPassword(String token, String newPassword) {
        PasswordResetToken t = tokens.findByToken(token == null ? "" : token)
                .filter(x -> !x.isUsed() && !x.isExpired())
                .orElseThrow(() -> new IllegalArgumentException("This reset link is invalid or has expired"));
        if (newPassword == null || newPassword.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters");
        }
        UserAccount acc = t.getUser();
        acc.setPassword(encoder.encode(newPassword));
        accounts.save(acc);
        t.setUsed(true);
        tokens.save(t);
    }
}
