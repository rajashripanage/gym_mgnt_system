package com.gym.service;

import com.gym.model.Invoice;
import com.gym.repository.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class DashboardService {

    private final MemberRepository members;
    private final TrainerRepository trainers;
    private final AttendanceRepository attendance;
    private final PaymentRepository payments;
    private final InvoiceRepository invoices;
    private final SupportQueryRepository queries;

    public DashboardService(MemberRepository members, TrainerRepository trainers, AttendanceRepository attendance,
                            PaymentRepository payments, InvoiceRepository invoices, SupportQueryRepository queries) {
        this.queries = queries;
        this.members = members;
        this.trainers = trainers;
        this.attendance = attendance;
        this.payments = payments;
        this.invoices = invoices;
    }

    public Map<String, Object> stats() {
        LocalDate today = LocalDate.now();
        BigDecimal pending = invoices.findAll().stream()
                .map(Invoice::getBalance)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<String, Object> s = new LinkedHashMap<>();
        s.put("totalMembers", members.count());
        s.put("activeMembers", members.countByActiveTrue());
        s.put("expiredMembers", members.countByExpiryDateBefore(today));
        s.put("totalTrainers", trainers.count());
        s.put("todayAttendance", attendance.countByAttendanceDate(today));
        s.put("totalRevenue", payments.totalRevenue());
        s.put("pendingDues", pending);
        s.put("todayCollection", payments.collectedOn(today));
        s.put("unassignedMembers", members.countByTrainerIsNull());
        s.put("openQueries", queries.countByStatus(com.gym.model.QueryStatus.OPEN));
        s.put("overdueInvoices", invoices.findAll().stream().filter(Invoice::isOverdue).count());
        return s;
    }
}
