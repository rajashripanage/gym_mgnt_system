package com.gym.service;

import com.gym.model.*;
import com.gym.repository.MemberRepository;
import com.gym.repository.SupportQueryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/** Member -> owner questions (support tickets). The member raises a query from his profile, the owner replies. */
@Service
public class QueryService {

    private final SupportQueryRepository queries;
    private final MemberRepository members;
    private final NotificationService notifications;

    public QueryService(SupportQueryRepository queries, MemberRepository members, NotificationService notifications) {
        this.queries = queries;
        this.members = members;
        this.notifications = notifications;
    }

    public List<SupportQuery> all() { return queries.findAllByOrderByUpdatedAtDesc(); }

    public List<SupportQuery> ofMember(Long memberId) { return queries.findByMemberIdOrderByUpdatedAtDesc(memberId); }

    public long openCount() { return queries.countByStatus(QueryStatus.OPEN); }

    public SupportQuery get(Long id) {
        return queries.findById(id).orElseThrow(() -> new IllegalArgumentException("Query not found"));
    }

    /** Same as get() but makes sure the query belongs to this member. */
    public SupportQuery getForMember(Long id, Long memberId) {
        SupportQuery q = get(id);
        if (!q.getMember().getId().equals(memberId)) {
            throw new IllegalArgumentException("Query not found");
        }
        return q;
    }

    @Transactional
    public SupportQuery create(Long memberId, String subject, QueryCategory category, String text) {
        if (subject == null || subject.isBlank()) throw new IllegalArgumentException("Subject is required");
        if (text == null || text.isBlank()) throw new IllegalArgumentException("Please write your question");
        Member member = members.findById(memberId).orElseThrow(() -> new IllegalArgumentException("Member not found"));

        SupportQuery q = new SupportQuery();
        q.setMember(member);
        q.setSubject(subject.trim().length() > 120 ? subject.trim().substring(0, 120) : subject.trim());
        q.setCategory(category == null ? QueryCategory.GENERAL : category);
        q.setStatus(QueryStatus.OPEN);
        addMessage(q, "MEMBER", text);
        q = queries.save(q);

        notifications.notifyOwner("New query from " + member.getName(), q.getSubject(), "/queries/" + q.getId());
        return q;
    }

    @Transactional
    public void memberReply(Long queryId, Long memberId, String text) {
        SupportQuery q = getForMember(queryId, memberId);
        if (text == null || text.isBlank()) throw new IllegalArgumentException("Message cannot be empty");
        addMessage(q, "MEMBER", text);
        q.setStatus(QueryStatus.OPEN);
        queries.save(q);
        notifications.notifyOwner("Reply from " + q.getMember().getName(), q.getSubject(), "/queries/" + q.getId());
    }

    @Transactional
    public void ownerReply(Long queryId, String text, boolean close) {
        SupportQuery q = get(queryId);
        if (text == null || text.isBlank()) throw new IllegalArgumentException("Reply cannot be empty");
        addMessage(q, "OWNER", text);
        q.setStatus(close ? QueryStatus.CLOSED : QueryStatus.ANSWERED);
        queries.save(q);
        notifications.notifyMember(q.getMember(), "Owner replied to your query", q.getSubject(), "/portal/queries/" + q.getId());
    }

    @Transactional
    public void setStatus(Long queryId, QueryStatus status) {
        SupportQuery q = get(queryId);
        q.setStatus(status);
        q.setUpdatedAt(LocalDateTime.now());
        queries.save(q);
    }

    @Transactional
    public void deleteForMember(Long memberId) {
        queries.deleteByMemberId(memberId);
    }

    private void addMessage(SupportQuery q, String sender, String text) {
        QueryMessage m = new QueryMessage();
        m.setQuery(q);
        m.setSender(sender);
        m.setText(text.trim());
        q.getMessages().add(m);
        q.setUpdatedAt(LocalDateTime.now());
    }
}
