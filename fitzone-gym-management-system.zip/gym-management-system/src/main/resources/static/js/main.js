// Navbar turns dark after scrolling
(function () {
    var nav = document.querySelector('.pub-nav');
    if (nav && !nav.classList.contains('solid')) {
        var onScroll = function () { nav.classList.toggle('scrolled', window.scrollY > 40); };
        window.addEventListener('scroll', onScroll); onScroll();
    }
    // Count-up numbers on the home page
    document.querySelectorAll('[data-count]').forEach(function (el) {
        var target = parseInt(el.getAttribute('data-count'), 10) || 0, cur = 0;
        var step = Math.max(1, Math.ceil(target / 40));
        var t = setInterval(function () {
            cur += step; if (cur >= target) { cur = target; clearInterval(t); }
            el.textContent = cur + (el.hasAttribute('data-plus') ? '+' : '');
        }, 30);
    });
    // Show / hide password
    document.querySelectorAll('[data-toggle-pass]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.getElementById(btn.getAttribute('data-toggle-pass'));
            input.type = input.type === 'password' ? 'text' : 'password';
            btn.querySelector('i').className = input.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
        });
    });
})();
