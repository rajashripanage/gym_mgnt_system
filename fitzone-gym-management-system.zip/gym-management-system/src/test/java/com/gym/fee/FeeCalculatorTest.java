package com.gym.fee;

import com.gym.model.PlanType;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FeeCalculatorTest {

    private static final BigDecimal BASE = new BigDecimal("1000.00");

    @Test
    void basicPlanHasNoDiscount() {
        assertEquals(0, FeeCalculatorFactory.forType(PlanType.BASIC).calculateDiscount(BASE).compareTo(BigDecimal.ZERO));
    }

    @Test
    void premiumPlanGetsFivePercent() {
        assertEquals(0, FeeCalculatorFactory.forType(PlanType.PREMIUM).calculateDiscount(BASE).compareTo(new BigDecimal("50.00")));
    }

    @Test
    void vipPlanGetsTenPercent() {
        assertEquals(0, FeeCalculatorFactory.forType(PlanType.VIP).calculateDiscount(BASE).compareTo(new BigDecimal("100.00")));
    }
}
